import "LevelTest.js";

document.write("I am writing things!");